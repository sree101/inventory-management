# InventoryManagement
INVENTORY MANAGEMENT USING CRUD
-- to create a mobile inventory management system where we create a database using mongodb , a server using express.js and web pages using ejs. This helps us to  do operations like Create, Retrieve, Update and Delete data from database using the developed web application.
